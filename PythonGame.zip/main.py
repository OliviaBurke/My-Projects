print("Hello Welcome to my Game!")
name = input("What is your name? ")
age = int(input("How old are you? "))

print("Hello ", name, "you are", age, ("years old."))

health = 10

if age >= 18:
    print("You are eligible to play!")
    wantsToPlay = input("Do you want to play? ").lower()
    if wantsToPlay == "yes":
        print("Let's play!")
        print("You are starting with", health, "health")
        leftOrRight = input(
            "First Choice: Do you want to go left or right (left/right)? ")
        if leftOrRight == "left":
            ans = input(
                "Good choice! You follow a path and reach a lake. Do you swim across or go around (across/around)? "
            )

            if ans == "around":
                print(
                    "You went around and reached the other side of the lake.")
            elif ans == "across":
                print(
                    "You managed to get across, but were bit by a piranha and lost 5 health."
                )
                health -= 5

            ans = input(
                "You notice a house and a river. Which do you go to (river/house)? "
            )
            if ans == "house":
                print("The owner is not happy to see you...you lose 5 health.")
                health -= 5
                if health <= 0:
                    print("You now have 0 health and you lost the game.")
                else:
                    print("You have survived and win the game!")
            else:
                print("You fell in the river and lost :(")

        else:
            print("You fell down and lost :( ")

    else:
        print("Goodbye")
else:
    print("You are not old enough to play :(")
